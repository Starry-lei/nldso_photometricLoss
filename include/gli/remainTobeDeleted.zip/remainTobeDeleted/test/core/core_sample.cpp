#include <gli/gli.hpp>

namespace test
{
	int test()
	{
		int Error(0);

		return Error;
	}
}//namespace test

int main()
{
	int Error(0);
		
	return Error;
}
