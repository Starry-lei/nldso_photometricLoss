var searchData=
[
  ['opengl_20image_20_28gli_29',['OpenGL Image (GLI)',['../index.html',1,'']]],
  ['opengl_20image_20_28gli_29_20licenses',['OpenGL Image (GLI) Licenses',['../a00008.html',1,'']]]
];
