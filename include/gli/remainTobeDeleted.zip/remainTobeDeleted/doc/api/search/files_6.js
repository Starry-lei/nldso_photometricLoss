var searchData=
[
  ['reduce_2ehpp',['reduce.hpp',['../a00048.html',1,'']]]
];
