var searchData=
[
  ['dx',['dx',['../a00011.html',1,'gli']]]
];
