var searchData=
[
  ['image',['image',['../a00013.html#ab4f40c94d3427e415d291c68d3e67cfa',1,'gli::image::image()'],['../a00013.html#a828b5030180522b6c967674f12085a91',1,'gli::image::image(format_type Format, extent_type const &amp;Extent)'],['../a00013.html#ab88ab938ed93fbb2e1cb9047aef29efa',1,'gli::image::image(image const &amp;Image, format_type Format)']]],
  ['is_5fborder',['is_border',['../a00076.html#a9175971af94a83b7fe6667b3c5b276c9',1,'gli']]],
  ['is_5fchannel',['is_channel',['../a00076.html#abf97bb3a068c322d88797b0e18209e16',1,'gli']]],
  ['is_5fcompressed',['is_compressed',['../a00076.html#a0034114c47df4c39d48ba964ab823f98',1,'gli']]],
  ['is_5fdds_5fext',['is_dds_ext',['../a00076.html#a5a607dedd5d94ffbb3112d9a4ea793f0',1,'gli']]],
  ['is_5fsrgb',['is_srgb',['../a00076.html#acc6f5ed334a41cfaa3733ec6abdb7da3',1,'gli']]],
  ['is_5ftarget_5f1d',['is_target_1d',['../a00076.html#a1f02f2a38031aa7eac76c7dd6cca6a7e',1,'gli']]],
  ['is_5ftarget_5farray',['is_target_array',['../a00076.html#aba272d7d816a08374f0899c9d96da7ab',1,'gli']]],
  ['is_5ftarget_5fcube',['is_target_cube',['../a00076.html#a4a9b9e0c1523b64082c93a9074b08c40',1,'gli']]],
  ['is_5ftarget_5frect',['is_target_rect',['../a00076.html#ab94f011e23ef8889a02061fcf457b56d',1,'gli']]],
  ['is_5fvalid',['is_valid',['../a00076.html#a63eba0158afbac2959449c8a7d9b806d',1,'gli']]]
];
