var searchData=
[
  ['duplicate_2ehpp',['duplicate.hpp',['../a00033.html',1,'']]],
  ['dx_2ehpp',['dx.hpp',['../a00034.html',1,'']]]
];
